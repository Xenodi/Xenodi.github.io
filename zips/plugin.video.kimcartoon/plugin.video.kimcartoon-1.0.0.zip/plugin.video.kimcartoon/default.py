# -*- coding: utf-8 -*-
from lib.main import main

main()